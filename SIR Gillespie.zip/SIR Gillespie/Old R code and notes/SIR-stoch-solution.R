# FUNCTION SIMULATING A STOCHASTIC SIR MODEL USING A GILLESPIE ALGORITHM
#
#   Input:
# 	parms:
#       a named vector of the parameters in the SIR model: (can be in any order)
#   	dS/dt = m*(S+I+R) - m*S - b*S*I
#   	dI/dt = b*S*I - (m+v)*I - r*I
#   	dR/dt = r*I - m*R
#
# 	initial:
#       a named vector of initial values for the variables S, I and R
#
# 	time.window:
#       specifies the start and end time of the simulation
#
# Output: a data.frame with one row per event; containing time, state. e.g. 
#             t  S  I  R
# 1   0.0000000 50  1  0
# 2   0.4202398 49  2  0
# 3   0.5046732 48  3  0
#     ...       ..  .  .

SIR.stoch = function(parms=c(m=1e-4,b=0.02,v=0.1,r=0.3),
                    initial=c(S=50, I=1, R=0),
                    time.window=c(0, 100)){
    
  # initialize state and time variables, make a dataframe to store the output
  # and store the initial state as the first line
  #  (btw- check out the difference between state["S"] and state[["S"]])
  state = initial
  time =  time.window[1]
  output = data.frame(t=time,
                       S=state["S"], I=state["I"], R=state["R"],
                       row.names=1)
  
  # define how state variables S, I and R change for each process
  processes = matrix(0, nrow=6, ncol=3,
                      dimnames=list(c("birth",
                        "death.S",
                        "infection",
                        "death.I",
                        "recovery",
                        "death.R"),
                        c("dS","dI","dR")))
  processes["birth"    ,"dS"] = +1
  processes["death.S"  ,"dS"] = -1
  processes["infection",c("dS","dI")] = c(-1,+1)
  processes["death.I"  ,"dI"] = -1
  processes["recovery" ,c("dI","dR")] = c(-1,+1)
  processes["death.R"  ,"dR"] = -1
                      
  # process propensities
  propensities = function(state){
    prop = with(as.list(c(state,parms)),  # this allows you to type "S" instead of state["S"]
                 c(birth=m*(S+I+R),       # and "m" instead of parms["m"],
                   death.S=m*S,			  #
                   infection=b*S*I,
                   death.I=(m+v)*I,
                   recovery=r*I,
                   death.R=m*R))
  }

  while(time < time.window[2] & state["I"]>0){

    # calculate process propensities for current state
    a = propensities(state)

    # WHEN does the next process happen?
    tau = rexp(1,rate=sum(a))  

    # update time
    time = time + tau

    # WHICH process happens after tau?
    i = sample.int(n=length(a), size=1, prob=a)

    # update states
    state = state + processes[i,]

    # write into output
    output = rbind(output,c(time,state))
  }

  output
  
}


# PLOT A SINGLE RUN OF THE SIMULATION
sim1 = SIR.stoch()  # without specification of variables defaults are used

plot(sim1$t, sim1$S,
     type="l", ylim=c(0,sim1$S[1]),
     xlab="time", ylab="population size")
lines(sim1$t, sim1$I, col=2)
lines(sim1$t, sim1$R, col=3)
legend("topright",legend=c("S","I","R"), lty=1, col=1:3, bty="n")


stop()

# NEXT WE STUDY THE RELATION BETWEEN THE EXTINCTION PROBABILITY AND
# THE BASIC REPRODUCTION NUMBER R0

# THIS IS A FUNCTION TO ESTIMATE THE EARLY EXTINCTION PROBABILITY
# OF THE STOCHASTIC SIR
# Input: 
#        runs: the number of runs of SIR.stoch used for estimating the
#              extinction probability
#        parms, initial are paased on to SIR.stoch (see that function
#              for details
#        t.end: the upper bound of the time.window in SIR.stoch
#
# Output: the extinction probability which is a number between 0 and 1
#
ext.prob = function(runs, parms, initial, t.end){
  sum(replicate(runs, min(SIR.stoch(parms,initial,c(0,t.end))["I"])==0)/runs)
}

# THIS FUNCTION CALCULATES THE R0:
# Input:  parms and initial which denote the same as in SIR.stoch
# output: R0
#
R0 = function(parms, initial){
  with(as.list(c(parms)),b*sum(initial)/(m+v+r))
}


# LET'S CALCULATE R0 AND EXT.PROB FOR DIFFERENT v AND PLOT
# first define a vector of values for v:
v.seq = c(200,20,2,seq(1,0,length=51))

# now calculate the corresponding R0:
R0.seq = sapply(v.seq,function(v) R0(c(m=1e-4,b=0.02,v=v,r=0.3),c(S=50, I=1, R=0)))

# and extinction probabilities:
# (this can take some time)
ext.prob.seq = sapply(v.seq,function(v) ext.prob(100,c(m=1e-4,b=0.02,v=v,r=0.3),c(S=50, I=1, R=0), 7))

# and now we plot the relation between R0 and extintiction probability:
plot(R0.seq, ext.prob.seq,
     xlab=expression(R[0]),ylab="Extinction probability",
     ylim=c(0,1), type="l")


# NEXT WE COMPARE THE MEAN OF THE STOCHASTIC WITH THE DETERMINISTIC MODEL

# FUNCTION CALCULATING THE DERIVATIVES OF THE SIR MODEL
# (THIS IS NEEDED IN SIR.determ BELOW AS AN ARGUMENT TO lsoda
# Input:
#       parms: the parameters in the SIR model:
#
#       x: are the values for the variables S, I and R
#
#       t: specifies the time at which the derivatives are to be calculated
#
# Output: a list with the derivatives dS/dt, dI/dt and dR/dt at time t
sir = function(t,x,parms){
        S = x["S"]
        I = x["I"]
        R = x["R"]
        with(as.list(c(parms)),{
             ds = m*(S+I+R) - m*S - b*I*S
             di = b*I*S - (m+v+r)*I
             dr = r*I - m*R
             der = c(ds,di,dr)
             list(der)
           })
}

# FUNCTION SIMULATING A DETERMINISTIC SIR MODEL USING lsoda
# Input:
#       parms: the parameters in the SIR model:
#
#       initial: are the initial values for the variables S, I and R
#
#       time.window: specifies the start and end time of the simulation
#
# Output: a data.frame that start approximately like
#      t  S  I  R
#1   0.5 50  1  0
#2   1.0 49  2  0
#3   1.5 48  3  0
#    ...       ..  .  .
SIR.determ = function(parms, initial, time.window){
  require(odesolve)
  times = seq(time.window[1], time.window[2], length=101)
  as.data.frame(lsoda(initial, times, sir, parms))
}

# THIS FUNCTION TAKES A DATAFRAME WITH THE RESULTS OF
# MULTIPLE RUNS OF SIR.stoch AND PUTS OUT A VECTOR OF
# A VARIABLE ("S", "I", or "R") AT TIME t
# Input:
#       sim: a data frame with columns run, t, S, I, R
#
#       var: the variable to be put out, either "S", "I", or "R"
#
# Ouput: a vector with the interpolated value of var at time t for
#        each run
#
intpol = function(sim, var, t){
  var.out = vector("numeric", length=length(unique(sim$run)))
  for(r in unique(sim$run)){
    ind = sim$run==r
    var.out[r] = stepfun(sim[ind,"t"],c(NA,sim[ind,var]))(t)
  }
  var.out
}


# DEFINE INITIAL PARAMETERS AND VARIABLES
init = c(S=50, I=1, R=0)
parms = c(m=1e-4,b=0.02,v=0.1,r=0.3)
tw = c(0,25)

# DO DETERMINISTIC SIMULATION
sim.determ = SIR.determ(parms,init,tw)

# DO 100 STOCHASTIC SIMULATION AND SAVE THEM INTO sims.100
# (this may take some time)
sims.100=cbind(run=1,SIR.stoch(parms,init,tw))
for(r in 2:100){
  sims.100 = rbind(sims.100,cbind(run=r,SIR.stoch(parms,init,tw)))
}
rm(r)

# CALCULATE THE MEANS IN SIMS.100
source("intpol.R")
t.seq = seq(1,100,1)
S.seq = sapply(t.seq, function(t) mean(intpol(sims.100,"S",t)))
I.seq = sapply(t.seq, function(t) mean(intpol(sims.100,"I",t)))
R.seq = sapply(t.seq, function(t) mean(intpol(sims.100,"R",t)))


# PLOT IT
# deterministic
plot(sim.determ$t, sim.determ$S,
       type="l", xlab="time", ylab="Population size", lty=2)
lines(sim.determ$t, sim.determ$I, lty=2, col=2)
lines(sim.determ$t, sim.determ$R, lty=2, col=3)

# stochastic
lines(t.seq,S.seq)
lines(t.seq,I.seq, col=2)
lines(t.seq,R.seq, col=3)

legend(0.8*max(sim.determ$t),0.9*max(sim.determ$S),
       legend=c("S","I","R","stoch","determ"),
       lty=c(1,1,1,1,2), col=c(1,2,3,1,1), bty="n")



# NOW WE PLOT THE DISTRIBUTION OF S and I AT DIFFERENT TIMES
par(mfrow=c(2,3))->op
hist(intpol(sims.100,"S",2 ),xlab="S",col=1)
hist(intpol(sims.100,"S",10),xlab="S",col=1)
hist(intpol(sims.100,"S",20),xlab="S",col=1)
hist(intpol(sims.100,"I",2 ),xlab="I",col=1)
hist(intpol(sims.100,"I",10),xlab="I",col=1)
hist(intpol(sims.100,"I",20),xlab="I",col=1)
par(op)

# AND CHECK FOR NORMALITY
par(mfrow=c(2,3))->op
qqnorm(intpol(sims.100,"S",2 ),xlab="S")
qqnorm(intpol(sims.100,"S",10),xlab="S")
qqnorm(intpol(sims.100,"S",20),xlab="S")
qqnorm(intpol(sims.100,"I",2 ),xlab="I")
qqnorm(intpol(sims.100,"I",10),xlab="I")
qqnorm(intpol(sims.100,"I",20),xlab="I")
par(op)



