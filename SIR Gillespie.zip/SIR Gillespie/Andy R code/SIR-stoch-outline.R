# FUNCTION SIMULATING A STOCHASTIC SIR MODEL USING A GILLESPIE ALGORITHM
# Input:
# 	parms:
#       a named vector of the parameters in the SIR model: (can be in any order)
#   	dS/dt = m*(S+I+R) - m*S - b*S*I
#   	dI/dt = b*S*I - (m+v)*I - r*I
#   	dR/dt = r*I - m*R
#
# 	initial:
#       a named vector of initial values for the variables S, I and R
#
# 	time.window:
#       specifies the start and end time of the simulation
#
# Output: a data.frame with one row per event; containing time, state. e.g. 
#             t  S  I  R
# 1   0.0000000 50  1  0
# 2   0.4202398 49  2  0
# 3   0.5046732 48  3  0
#     ...       ..  .  .

SIR.stoch = function(parms=c(m=1e-4,b=0.02,v=0.1,r=0.3),
                    initial=c(S=50, I=1, R=0),
                    time.window=c(0, 100)){
    
  # initialize state and time variables, make a dataframe to store the output
  # and store the initial state as the first line
  state = initial
  time =  time.window[1]
  output = data.frame(t=time,
                       S=state["S"], I=state["I"], R=state["R"],
                       row.names=1)
  
  # define how state variables S, I and R change for each process
  processes = matrix(0, nrow=6, ncol=3,
                      dimnames=list(c("birth",
                        "death.S",
                        "infection",
                        "death.I",
                        "recovery",
                        "death.R"),
                        c("dS","dI","dR")))
  <...>
  processes["infection",c("dS","dI")] = c(-1,+1)
  <...>
                      
  # process 
  propensities = function(state){
    <...>
  }


  while(time < time.window[2] & state["I"]>0){

    # calculate process probabilities for current state
    <...>

    # WHEN does the next process happen?
    <...>

    # update time
    <...>

    # WHICH process happens after tau?
    <...>

    # update states
    <...>

    # write into output
    output = rbind(output,c(time,state))
  }

  output
  
}

# PLOT A SINGLE RUN OF THE SIMULATION
sim1 = SIR.stoch()  # without specification of variables, the  defaults are used




# EXERCISE: THE RELATION BETWEEN THE EXTINCTION PROBABILITY AND
# THE BASIC REPRODUCTIVE NUMBER R0

# ESTIMATE THE EXTINCTION PROBABILITY
# Input: 
#        runs: the number of runs of SIR.stoch you want to use to estimate the
#              extinction probability
#        parms, initial are paased on to SIR.stoch (see that function
#              for details)
#        t.end: the upper bound of the time.window in SIR.stoch
#
# Output: the extinction probability -  a number between 0 and 1
#
ext.prob = function(runs, parms, initial, t.end){
 # perform "runs" simulations,
 # and for each record TRUE if it went extinct, FALSE if not
 # Then return the proportion that went extinct
 <....>
 }

# CALCULATE R0:
# Input:  parms and initial (passed to SIR.stoch)
# output: R0
#
R0 = function(parms, initial){
  with(as.list(c(parms)),b*sum(initial)/(m+v+r))
}

# CALCULATE R0 AND EXT.PROB FOR DIFFERENT v,  AND PLOT

# first define a vector of values for v:
v.seq = c(200,20,2,seq(1,0,length=51))

# now calculate a vector of the same length, with the corresponding R0:
# hint - use sapply

R0.seq = <....>

# now calculate an estimate of the extinction probability at each of these values of v
# hint 1 - use sapply with the function ext.prob
# hint 2 - when you simulate, choose an end time of 7
#    look for yourself - it appears if a run has not gone extinct by this time,
# it's  unlikely to in the future
# 
# However you do this, the code may take some time to run...
# for each value of v it will run 100 simulations, remember.
# 
ext.prob.seq = <....>

# and now we can plot the relation between R0 and extinction probability:
plot(R0.seq, ext.prob.seq,
     xlab=expression(R[0]),ylab="Extinction probability",
     ylim=c(0,1), type="l")



