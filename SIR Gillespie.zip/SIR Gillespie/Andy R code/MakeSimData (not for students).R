initial=c(S=50, I=1, R=0)
timepoints=seq(0,15,by=0.2)
param.values=c(m=2e-4,b=0.02,v=0.1,r=0.3)
# Solve the system of ODEs and return the output in a dataframe
soln=lsoda(y=initial, times=timepoints, func=SIR.ode.model, parms=param.values)
# lsoda returns the answer as a matrix. For referring to bits of this, it's easier to coneert it to a dataframe
soln=as.data.frame(soln)
tmp=log(soln$I)
tmp=tmp+rnorm(length(tmp), sd=0.2)
observed.infecteds=exp(tmp)
plot(observed.infecteds ~ timepoints)
# plot it

sim=data.frame(Day=timepoints, Infected=observed.infecteds)
sim[1,]=c(0,1)
write.table(sim, "Sim.txt", quote=FALSE)
