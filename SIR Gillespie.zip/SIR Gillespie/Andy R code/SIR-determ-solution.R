# Estimating infection parameters from an SIR model

setwd("~/Documents/Teaching/R course Einstein/2012/Datasets")

# install.packages("deSolve")
#
# We're going to use the function "lsoda" to solve the
# SIR differential equation model
#
# "lsoda" is a solver that needs arguments (y, times, func, parms)
# where
#	y = initial state for sWystem (S,I,R)
#	times =  the times we want to output the solution
#				(first time point = initial state)
#	func = name of a function that gives you the
#			derivatives dS/dt, dI/dt, dR/dt (see below)
#	params = is a named vector of parameter values 

# Here is the function that generates the derivatives.
# lsoda expects this function to have the arguments
#     t (time), x (current state), parms (parameter values)

library(deSolve)

SIR.ode.model = function(t, x, parms) { 
#  Here, `with'  allows us to use the values of
# m,b,... and S, I, R named in 'parms' and 'x'
  with(as.list(c(parms, x)),{ 
    S.dot =m*(S+I+R) - m*S - b*S*I
    I.dot= b*S*I - (m+v)*I - r*I
    R.dot= r*I- m*R
    list(c(S.dot,I.dot, R.dot))  # must return derivatives as a list
  }) 
}

# we'll simulate a deterministic epidemic 
initial=c(S=50, I=1, R=0)
timepoints=0:25
param.values=c(m=2e-4,b=0.02,v=0.1,r=0.3)

# Solve the system of ODEs
soln=lsoda(y=initial, times=timepoints, func=SIR.ode.model, parms=param.values)

# lsoda returns the answer as a matrix.
# For referring to bits of this, it's easier to convert it to a dataframe
soln=as.data.frame(soln)

# Using this dataframe, plot S,I,R on the same graph and add a legend
plot(S~time, data=soln, col="darkgreen", lwd=2, type="l", ylim=c(0,51),las=1, ylab="Population size")
lines(I~time, data=soln, col="darkred", lwd=2)
lines(R~time, data=soln, col="lightskyblue2", lwd=2)
legend("topright", legend=c("S", "I", "R"), col=c("darkgreen","darkred", "lightskyblue2"), lwd=2, bty="n")

stop()


############################################################


# Read in data from an epidemic - infected numbers over time
epidemic=read.table("epidemic.txt", header=TRUE)

# plot it
plot(Infected ~ Day,epidemic)

# For this epidemic we know the parameters m, v, and r and that N=50
known.param.values=c(m=2e-4,v=0.1,r=0.3)

# ... and we want to estimate the infectivity parameter b.
# From that we can get R0.

# Write a function that inputs a value for the parameter b
# and a vector "times" (times at which to output the model results)
# and returns a vector of predicted values of infected numbers at "times"

predicted.infecteds=function(b, timepoints){
    soln=as.data.frame(
    	lsoda(y=initial, times=timepoints, func=SIR.ode.model, parms=c(b=b, known.param.values))
    	)
	return(soln[["I"]])
	}

# use "nls" (nonlinear least squares) to estimate b
# similar syntax to lm for a linear model,
# but you need to give an initial guess for
# the parameter. A guess of b=0 works fine here.
fit=nls(Infected ~ predicted.infecteds(b, Day),data=epidemic, start=list(b=0))

# add the fitted curve to the plot of the raw data
# hint - use fitted(fit) to get the predicted values from the fitted object.
lines(fitted(fit) ~ epidemic$Day) 

# Fit looks ok-ish
# but we need to check that the residuals (observed-predicted)
# have a constant variance
# this is an assumption of the fitting routine
plot(resid(fit) ~ fitted(fit))

# residuals increase in size with the observation size 
# One possibility is that the errors are normal on a log scale:
# this is common with exponential growth/decay processes
# refit with log-transformed infected cell counts,
# plot the data and fit on this new scale, and in a new plot look at the residuals again
fit=nls(log(Infected) ~ log(predicted.infecteds(b, Day)), data=epidemic, start=list(b=0.0))
plot(log(Infected) ~ Day, data=epidemic)
lines(fitted(fit) ~ epidemic$Day)
plot(resid(fit) ~ fitted(fit))
# looks better

# Get estimate of b
b.est=coef(fit)
# use "as.numeric" to strip the name off (helps later)
b.est=as.numeric(b.est)


##############################################################################
#
# Bootstrapping

## How certain are we of our parameter estimate b?
# R gives you a rough estimate using likelihood profiling

confint(fit)

# Alternative - 

# Resample the residuals to get a confidence interval

# First, store the best-fit residuals and fitted values
saved.residuals=resid(fit)
bestfit.values=fitted(fit)

# make an empty vector of size 'replicates' to store the estimates of b
replicates=100
b.estimates=rep(0,replicates)

# loop through replicates
for(i in 1:replicates){
 # make a new resampled observation by adding
 # resampled residuals to the predicted values
 resampled.observations=bestfit.values+ sample(saved.residuals, replace=TRUE)
 # use this to make a new dataframe with columns "Day" and "Log.Infected"
 resampled.data=data.frame(Day=epidemic$Day,Log.Infected=resampled.observations)
 # get a new estimate of b from this 'fake' data and store it
 fit=nls(Log.Infected ~ log(predicted.infecteds(b, Day)), data=resampled.data, start=list(b=0.01))
 b.estimates[i]=coef(fit)
 }
  # plot a histogram or density plot of this set of estimates of b
 plot(density(b.estimates))
 
 # estimate the 95% CI with the 2.5% and 97.5 quantiles of this vector
 CI=as.numeric(quantile(b.estimates, c(0.025, 0.975)) )

# Let's plot the data, the best fit, and the 95% confidence region. We'll 
# build this up layer by layer 

# To make a smooth curve,
# make a vector of timepoints that spans the timerange of the data
# and is 100 timepoints long 

fine.times=seq(from=min(epidemic$Day), to=max(epidemic$Day), length=100)

# Use these to generate the best-fit predicted values at these timepoints with
# the "predicted.infecteds" function
best.fit=log(predicted.infecteds(as.numeric(b.est), fine.times))

# do same using the upper and lower ends of the 95% CI for b
lower95=log(predicted.infecteds(as.numeric(CI[1]), fine.times))
upper95=log(predicted.infecteds(as.numeric(CI[2]), fine.times))

# make an empty plot that holds all the raw data
# (hint - use type="n" to not plot any points)
plot(log(Infected)~Day, data=epidemic,type="n")

# add the upper and lower CI curves in red
lines(lower95~fine.times, col="red")
lines(upper95~fine.times, col="red")

# shade in the 95% CI
polygon(c(fine.times, rev(fine.times)), c(lower95, rev(upper95)), border=NA, col="lightskyblue1")

# add the best fit line
lines(best.fit~fine.times, col="darkblue")

# add the data
points(log(Infected)~Day, data=epidemic, pch=19)


#######################################################################################
# Lastly... What's the estimate and 95% CI of R0? Remember R0= b*N/(m+v+r)

the.rest=50/with(as.list(known.param.values), m+v+r)
R0=b.est*the.rest
R0.CI = CI*the.rest


