# FUNCTION SIMULATING A STOCHASTIC SIR MODEL USING THE GILLESPIE ALGORITHM
#
#   Input:
# 	parms:
#       a named vector of the parameters in the SIR model: (can be in any order)
#   	dS/dt = m*(S+I+R) - m*S - b*S*I
#   	dI/dt = b*S*I - (m+v)*I - r*I
#   	dR/dt = r*I - m*R
#
# 	initial:
#       a named vector of initial values for the variables S, I and R
#
# 	time.window:
#       specifies the start and end time of the simulation
#
# Output: a data.frame with one row per event; containing time, state. e.g. 
#             t  S  I  R
# 1   0.0000000 50  1  0
# 2   0.4202398 49  2  0
# 3   0.5046732 48  3  0
#     ...       ..  .  .

# the numbers we supply here are the default arguments
# The function will use these if you don't pass your own values in.
SIR.stoch = function(parms=c(m=1e-4,b=0.02,v=0.1,r=0.3),
                    initial=c(S=50, I=1, R=0),
                    time.window=c(0, 100)){
    
  # initialize state and time variables, make a dataframe to store the output
  # and store the initial state as the first line
  #  (btw- check out the difference between state["S"] and state[["S"]] - it's usually irrelevant)
  state = initial
  time =  time.window[1]
  output = data.frame(t=time,
                       S=state["S"], I=state["I"], R=state["R"],
                       row.names=1)
  # define how state variables S, I and R change for each process
  processes = matrix(0, nrow=6, ncol=3,
                      dimnames=list(c("birth",
                        "death.S",
                        "infection",
                        "death.I",
                        "recovery",
                        "death.R"),
                        c("dS","dI","dR")))
  processes["birth"    ,"dS"] = +1
  processes["death.S"  ,"dS"] = -1
  processes["infection",c("dS","dI")] = c(-1,+1)
  processes["death.I"  ,"dI"] = -1
  processes["recovery" ,c("dI","dR")] = c(-1,+1)
  processes["death.R"  ,"dR"] = -1
                      
  # process propensities
  # here we use "with" - very useful - saves a lot of typing and looks clearer
  # with(list(a=1, b=2, ...), { <.....> }) means inside the curly brackets we can 
  # refer to a and b as if they are variables
  # remember at the moment m, S, etc. are not defined as variables - they're just 
  # names of components of the vectors parms and state
  # "with" needs to be given a list as its first argument
  # (because lists can contain any kind of object,
  # and you might want to use any sort of object inside the "with")
  # so we combine state and parms into one vector c(state, parms) and cast it into a list with "as.list"
  propensities = function(state, parms){
    prop = with(as.list(c(state,parms)),  
                 c(birth=m*(S+I+R),       
                   death.S=m*S,			  
                   infection=b*S*I,
                   death.I=(m+v)*I,
                   recovery=r*I,
                   death.R=m*R))
    return(prop)  # clearer to write this but you can omit it - here the last thing R does is calculate "prop"
                  # so that would be the value of the function.
  }
  
  while(time < time.window[2] & state["I"]>0){

    # calculate process propensities for current state
    a = propensities(state, parms)

    # WHEN does the next process happen?
    tau = rexp(1,rate=sum(a))  

    # update time
    time = time + tau

    # WHICH process happens after tau?
    i = sample.int(n=length(a), size=1, prob=a)

    # update states
    state = state + processes[i,]

    # write into output
    output = rbind(output,c(time,state))
  }

  return(output)
  
}

# PLOT A SINGLE RUN OF THE SIMULATION
# It will run until it goes extinct or until time=100
sim1 = SIR.stoch()  # without specification of variables, the defaults are used
stop()


colours=c(S="darkgreen", I="darkred", R="deepskyblue")
plot(sim1$t, sim1$S,
     type="l", ylim=c(0,sim1$S[1]),col=colours[["S"]],lwd=2,
     xlab="time", ylab="population size", main="Simulated Epidemic",las=1)
     # remember las=1 is to with axis labels - see ?par
lines(sim1$t, sim1$I, col=colours[["I"]], lwd=2)
lines(sim1$t, sim1$R, col=colours[["R"]], lwd=2)
legend("topright",legend=c("S","I","R"), lty=1, lwd=2, col=colours, bty="n")


#or

matplot(sim1[,1], sim1[,2:4], type="l")
stop()
# stop()  # useful to halt code. it will claim there is an error - but don't worry.

# EXERCISE: THE RELATION BETWEEN THE EXTINCTION PROBABILITY AND
# THE BASIC REPRODUCTIVE NUMBER R0

# ESTIMATE THE EXTINCTION PROBABILITY
# Input: 
#        runs: the number of runs of SIR.stoch you want to use to estimate the
#              extinction probability
#        parms, initial are passed on to SIR.stoch
#			(see that function for details)
#        t.end: the upper bound of the time.window in SIR.stoch
#
# Output: the extinction probability -  a number between 0 and 1
#
ext.prob = function(runs, parms, initial, t.end){
 # perform "runs" simulations,
 # and for each record TRUE if it went extinct, FALSE if not
 # Then return the proportion that went extinct
  extinction.yes=replicate(runs, min(SIR.stoch(parms,initial,c(0,t.end))["I"])==0)
  sum(extinction.yes)/runs
 }

# CALCULATE R0:
# Input:  parms and initial (passed to SIR.stoch)
# output: R0
#
R0 = function(parms, initial){
  with(as.list(c(parms)),b*sum(initial)/(m+v+r))
}

# CALCULATE R0 AND EXT.PROB FOR DIFFERENT v,  AND PLOT

# first define a vector of values for v:
v.seq = c(200,20,2,seq(1,0,length=51))

# now calculate a vector of the same length, with the corresponding R0:
# here we use sapply(x, FUN) to apply the function FUN to each element of the vector x
# I've not named the function - i just defined it inline. Also note that since the function only has one command in it
# (the call to the function R0) I don't need to put curly brackets around it.
R0.seq =  sapply(v.seq,function(v) R0(c(m=1e-4,b=0.02,v=v,r=0.3),c(S=50, I=1, R=0)))

# now calculate an estimate of the extinction probability at each of these values of v
# When we simulate, to save time we choose an end time of 7
# Look for yourself - it appears if a run has not gone extinct by this time,
# it's unlikely to in the future, so we may as well stop that simulation.
# 
# However you do this, the code may take some time to run. For each value of v
# it will run 100 simulations, remember. 
ext.prob.seq = sapply(v.seq,
           function(v) ext.prob(runs=100,parms= c(m=1e-4,b=0.02,v=v,r=0.3),initial=c(S=50, I=1, R=0), t.end=7)
           )

# and now we can plot the relation between R0 and extinction probability:
plot(R0.seq, ext.prob.seq,
     xlab=expression(R[0]),ylab="Extinction probability",
     ylim=c(0,1), type="l", las=1)
# put a guideline in at R0=1 to see the threshold more clearly
# i.e. for R0>1, a deterministic simulation would never go extinct so we would expect the 
# curve to drop to zero here.
abline(v=1, lty=2, col="red") 


