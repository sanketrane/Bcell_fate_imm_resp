# Estimating infection parameters from an SIR model

# install the deSolve package if it's not installed already
if (!require("deSolve")) install.packages("deSolve", dependencies=TRUE)

#
# We're going to use the function "lsoda" to solve the
# SIR differential equation model
#
#
# "lsoda" is a function that solves differential equations
# It needs arguments (y, times, func, parms)
# where
#	y = initial state for system (S,I,R)
#	times =  the times we want to output the solution
#				(first time point = initial state)
#	func = name of a function that gives you the
#			derivatives dS/dt, dI/dt, dR/dt (see below)
#	params = is a named vector of parameter values 

# Here is the function that generates the derivatives.
# lsoda expects this function to have the arguments
#     t (time), x (current state), parms (parameter values)
#
# it outputs a matrix - first column is the time values you wanted
# outputs at, and the other columns are the values of the variables


library(deSolve)

SIR.ode.model = function(t, x, parms) { 
# Here, remember that `with'  allows us to use the values of
# m,b,v, r, S, I, R named in 'parms' and 'x'
 
  with(as.list(c(parms, x)),{ 
    dS.dt =m*(S+I+R) - m*S - b*S*I
    dI.dt= b*S*I - (m+v)*I - r*I
    dR.dt= r*I- m*R
    # lsoda needs you to return derivatives as a list
    return(list(c(dS.dt,dI.dt, dR.dt)))  
  }) 
}

# we'll simulate a deterministic epidemic 
initial=c(S=50, I=1, R=0)
timepoints=0:25
param.values=c(m=2e-4,b=0.02,v=0.1,r=0.3)

# Solve the system of ODEs
soln=lsoda(y=initial, times=timepoints, func=SIR.ode.model, parms=param.values)

# lsoda returns the answer as a matrix.
# For referring to bits of this, it's easier to convert it to a dataframe
soln=as.data.frame(soln)

# Using this dataframe, plot S,I,R on the same graph and add a legend

<....>

legend("topright", legend=c("S", "I", "R"), col=c("darkgreen","darkred", "lightskyblue2"), lwd=2, bty="n")


############################################################


# Read in data from an epidemic - infected numbers over time

epidemic=read.table("epidemic.txt", header=TRUE)

# plot it
<...>

# For this epidemic we know the parameters m, v, and r and that N=50
known.param.values=c(m=2e-4,v=0.1,r=0.3)

# ... and we want to estimate the infectivity parameter b.
# From that we can get R0.

# Write a function that inputs a value for the parameter b
# and a vector "timepoints" (times at which to output the model results)
# and returns a vector of predicted values of infected numbers at "timepoints"

predicted.infecteds=function(b, timepoints){
   <....>
   }

# use "nls" (nonlinear least squares) to estimate b
# similar syntax to lm for a linear model,
# but you need to give an initial guess for
# the parameter. A guess of b=0 works fine here.
fit=nls(Infected ~ predicted.infecteds(b, Day),data=epidemic, start=list(b=0))

# add the fitted curve to the plot of the raw data
# hint - use fitted(fit) to get the predicted values from the fitted object.

<...>

# Fit looks ok-ish
# but we need to check that the residuals (observed minus predicted)
# have a constant variance
# this is an assumption of (non-)linear least squares estimation
plot(resid(fit) ~ fitted(fit))

# residuals increase in size with the observation size 
# this suggests the errors are normal on a log scale:
# Refit with log-transformed infected cell counts,
# plot the fit on this scale, and look at the residuals again
<....>
# ... residuals should look better

# Get estimate of b
b.est=coef(fit)
# use "as.numeric" to strip the name off (helps later)
b.est=as.numeric(b.est)



##############################################################################
#
# Bootstrapping

## How certain are we of our parameter estimate b?
# R gives you a rough estimate using likelihood profiling

confint(fit)

# Alternative - 

# Resample the residuals to get a confidence interval
# See lecture notes for an explanation of the method

# First, store the best-fit residuals and fitted values
saved.residuals=resid(fit)
bestfit.values=fitted(fit)

# make an empty vector of size 'replicates' to store the estimates of b
replicates=100
b.estimates=rep(0,100)

# loop through replicates
for(i in 1:replicates){
 # make a new resampled observation by adding
 # resampled residuals to the predicted values
 resampled.observations = bestfit.values+sample(saved.residuals, replace=TRUE)
 # use this to make a new dataframe with columns "Day" and "Log.Infected"
 resampled.dataframe=data.frame(Day=epidemic$Day, Log.Infected=resampled.observations)
 # get a new estimate of b from this 'fake' data and store it
 fit=nls(Log.Infected~ predicted.infecteds(b, Day), data=resampled.dataframe, start=c(b=0.0))
 b.estimates[i]=as.numeric(coef(fit))
 }
 # plot a histogram or density plot of this set of estimates of b
<...>

# estimate the 95% CI with the 2.5% and 97.5 quantiles of this vector
CI=quantile(b.estimate, c(0.025,0.975))

# Let's plot the data, the best fit, and the 95% confidence region. We'll 
# build this up layer by layer 

# To make a smooth curve,
# make a vector of timepoints that spans the timerange of the data
# and is 100 timepoints long 
fine.times=<...>

# Use these to generate the best-fit predicted values at these timepoints with
# the "predicted.infecteds" function
best.fit=<...>

# do same using the upper and lower ends of the 95% CI for b
lower95=<...>
upper95=<...>

# make an empty plot that holds all the raw data
# (hint - use type="n" to not plot any points)
<...>
 # add the upper and lower CI curves in red
<...>

# add the best fit line in darkblue
<....>

# lastly add the actual data
<...>


#######################################################################################
# Lastly... What's the estimate and 95% CI of R0? Remember R0= b*N/(m+v+r)

<...>


